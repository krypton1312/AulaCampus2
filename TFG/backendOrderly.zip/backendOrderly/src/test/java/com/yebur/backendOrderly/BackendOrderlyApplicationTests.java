package com.yebur.backendOrderly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendOrderlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
