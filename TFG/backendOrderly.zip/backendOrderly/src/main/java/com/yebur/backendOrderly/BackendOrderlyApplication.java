package com.yebur.backendOrderly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendOrderlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendOrderlyApplication.class, args);
	}

}
