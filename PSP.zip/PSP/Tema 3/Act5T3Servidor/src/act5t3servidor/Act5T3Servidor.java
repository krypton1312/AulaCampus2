package act5t3servidor;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class Act5T3Servidor {
    public static void main(String[] args) throws SocketException, IOException {
        List<Libro> libros = new ArrayList<>();
        libros.add(new Libro("El principito ? Antoine de Saint-Exupery","Un piloto perdido en el desierto se encuentra con un peque�o pr�ncipe que viene de otro planeta. A trav�s de sus conversaciones, el principito ense�a valiosas lecciones sobre la amistad, el amor y la verdadera esencia de las cosas, que solo se ve con el coraz�n."));
        libros.add(new Libro("Harry Potter y la piedra filosofal ? J.K. Rowling", "Harry, un ni�o hu�rfano que vive con sus crueles t�os, descubre que es un mago. Al ingresar al colegio Hogwarts de magia y hechicer�a, encuentra amigos, enemigos y un misterioso secreto sobre su pasado y el poder oscuro que amenaza su mundo."));
        libros.add(new Libro("Cien a�os de soledad ? Gabriel Garc�a Marquez", "La novela narra la historia de la familia Buend�a a lo largo de varias generaciones en el m�tico pueblo de Macondo. Es una obra que mezcla la realidad con la fantas�a, explorando el amor, la soledad y el destino inevitable de sus personajes."));
        
        DatagramSocket socket = new DatagramSocket(6480);
        
        byte[] buffer = new byte[1000];
        
        System.out.println("Esperando paquetes...");
        while(true){
            DatagramPacket paqRecibido = new DatagramPacket(buffer, buffer.length);
            socket.receive(paqRecibido);
            
            String titulo = new String(paqRecibido.getData()).trim();
            
            System.out.println("Titulo recibido: " + titulo);
            
            DatagramPacket paqueteEnviado;
            for(Libro l: libros){
                if(l.titulo().contains(titulo)){
                    paqueteEnviado = new DatagramPacket(l.sinopsis().getBytes(), l.sinopsis().getBytes().length, paqRecibido.getAddress(), paqRecibido.getPort());
                    socket.send(paqueteEnviado);
                }else{
                    byte[] mensaje = "Pelicula con este titulo no ha sido encontrada".getBytes();
                    paqueteEnviado = new DatagramPacket(mensaje, mensaje.length, paqRecibido.getAddress(), paqRecibido.getPort());
                    socket.send(paqueteEnviado);
                }
            }
        }
    }
}


record Libro(String titulo, String sinopsis){};
